// Firebase Configuration Setup Instructions:
// 1. Go to the Firebase Console: https://console.firebase.google.com/
// 2. Click "Add project" and follow the steps to create a new project.
// 3. In the Project Overview, click the "Web" icon (</>) to register a new web app.
// 4. Copy the `firebaseConfig` object provided by Firebase.
// 5. In the Firebase Console sidebar, go to "Build" > "Realtime Database".
// 6. Click "Create Database", choose a location, and start in "Test mode" (this allows anyone to read/write for 30 days).
// 7. Paste your config below.

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getDatabase, ref, set, onValue, remove, onDisconnect, off, update } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";

const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
let app, db;
if (firebaseConfig.apiKey !== "YOUR_API_KEY") {
    app = initializeApp(firebaseConfig);
    db = getDatabase(app);
} else {
    console.warn("Firebase not configured. Please update firebaseConfig in script.js");
}

// State variables
let currentRoom = null;
let currentPlayerId = null;
let isMyTurn = false;

// DOM Elements
const setupScreen = document.getElementById("setup-screen");
const gameScreen = document.getElementById("game-screen");
const displayRoomCode = document.getElementById("display-room-code");
const playersList = document.getElementById("players-list");
const gameStatus = document.getElementById("game-status");
const playArea = document.getElementById("play-area");
const myHandContainer = document.getElementById("my-hand");

// Generate a random 6-character room code
function generateRoomCode() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "";
    for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// Create a new room
document.getElementById("btn-create-room").addEventListener("click", async () => {
    if (!db) return alert("Firebase not configured! Check the instructions in script.js");

    const playerName = document.getElementById("player-name-create").value.trim();
    if (!playerName) return alert("Please enter your name");

    const roomCode = generateRoomCode();
    currentPlayerId = "player_" + Math.random().toString(36).substr(2, 9);
    
    const roomData = {
        state: "waiting",
        turn: null,
        players: {
            [currentPlayerId]: {
                name: playerName,
                isHost: true,
                hand: []
            }
        },
        lastPlayedCard: null
    };

    try {
        await set(ref(db, "rooms/" + roomCode), roomData);
        joinRoomUI(roomCode);
    } catch (error) {
        console.error("Error creating room:", error);
    }
});

// Join an existing room
document.getElementById("btn-join-room").addEventListener("click", () => {
    if (!db) return alert("Firebase not configured!");

    const playerName = document.getElementById("player-name-join").value.trim();
    const roomCode = document.getElementById("room-code-input").value.trim().toUpperCase();
    
    if (!playerName) return alert("Please enter your name");
    if (!roomCode || roomCode.length !== 6) return alert("Please enter a valid 6-character room code");

    const roomRef = ref(db, "rooms/" + roomCode);
    onValue(roomRef, (snapshot) => {
        const data = snapshot.val();
        if (snapshot.exists()) {
            if (Object.keys(data.players || {}).length >= 2) {
                return alert("Room is full!");
            }

            currentPlayerId = "player_" + Math.random().toString(36).substr(2, 9);
            
            // Add player to room
            update(ref(db, `rooms/${roomCode}/players/${currentPlayerId}`), {
                name: playerName,
                isHost: false,
                hand: []
            }).then(() => {
                joinRoomUI(roomCode);
            });
        } else {
            alert("Room not found!");
        }
    }, { onlyOnce: true });
});

// Leave room
document.getElementById("btn-leave-room").addEventListener("click", () => {
    if (currentRoom && currentPlayerId && db) {
        remove(ref(db, `rooms/${currentRoom}/players/${currentPlayerId}`)).then(() => {
            gameScreen.classList.add("hidden");
            setupScreen.classList.remove("hidden");
            off(ref(db, 'rooms/' + currentRoom));
            currentRoom = null;
            currentPlayerId = null;
        });
    }
});

// Update UI after joining a room and setup Firebase listeners
function joinRoomUI(roomCode) {
    currentRoom = roomCode;
    displayRoomCode.innerText = roomCode;
    setupScreen.classList.add("hidden");
    gameScreen.classList.remove("hidden");

    const roomRef = ref(db, "rooms/" + roomCode);

    onValue(roomRef, (snapshot) => {
        const data = snapshot.val();
        if (!data) return;
        
        handleGameSync(data);
    });
    
    onDisconnect(ref(db, `rooms/${roomCode}/players/${currentPlayerId}`)).remove();
}

// Main game logic and synchronization
async function handleGameSync(roomData) {
    const players = roomData.players || {};
    const playerIds = Object.keys(players);
    
    // 1. Auto-start game if 2 players and still in waiting state
    if (roomData.state === "waiting" && playerIds.length === 2 && players[currentPlayerId].isHost) {
        startGame(playerIds);
        return;
    }

    // 2. Update Turn Status
    isMyTurn = roomData.turn === currentPlayerId;
    if (roomData.state === "playing") {
        gameStatus.innerText = isMyTurn ? "Your Turn!" : "Waiting for opponent...";
    } else {
        gameStatus.innerText = "Waiting for players...";
    }

    // 3. Render Players
    playersList.innerHTML = '';
    playerIds.forEach(id => {
        const p = players[id];
        const div = document.createElement('div');
        div.className = `player-item ${roomData.turn === id ? 'active' : ''}`;
        div.innerText = `${p.name}${id === currentPlayerId ? ' (You)' : ''}`;
        playersList.appendChild(div);
    });

    // 4. Render Play Area
    playArea.innerHTML = 'Play Area';
    if (roomData.lastPlayedCard) {
        const card = createCardElement(roomData.lastPlayedCard.value);
        playArea.appendChild(card);
        const nameLabel = document.createElement('div');
        nameLabel.innerText = `By ${players[roomData.lastPlayedCard.by].name}`;
        nameLabel.style.marginTop = '10px';
        playArea.appendChild(nameLabel);
    }

    // 5. Render My Hand
    myHandContainer.innerHTML = '';
    const myHand = players[currentPlayerId]?.hand || [];
    myHand.forEach((val, index) => {
        const card = createCardElement(val);
        card.addEventListener('click', () => playCard(index, val));
        myHandContainer.appendChild(card);
    });
}

// Start game: Initialize hands and first turn (called by host)
function startGame(playerIds) {
    const updates = {};
    updates[`rooms/${currentRoom}/state`] = "playing";
    updates[`rooms/${currentRoom}/turn`] = playerIds[0];
    
    playerIds.forEach(id => {
        const hand = [];
        for (let i = 0; i < 5; i++) {
            hand.push(Math.floor(Math.random() * 10) + 1); // 1-10
        }
        updates[`rooms/${currentRoom}/players/${id}/hand`] = hand;
    });

    update(ref(db), updates);
}

// Play a card from hand
function playCard(cardIndex, cardValue) {
    if (!isMyTurn) {
        alert("It's not your turn!");
        return;
    }

    onValue(ref(db, 'rooms/' + currentRoom), (snapshot) => {
        const data = snapshot.val();
        const players = data.players;
        const playerIds = Object.keys(players);
        const opponentId = playerIds.find(id => id !== currentPlayerId);
        
        // Remove card from my hand
        const newHand = [...players[currentPlayerId].hand];
        newHand.splice(cardIndex, 1);
        
        const updates = {};
        updates[`rooms/${currentRoom}/players/${currentPlayerId}/hand`] = newHand;
        updates[`rooms/${currentRoom}/lastPlayedCard`] = { value: cardValue, by: currentPlayerId };
        updates[`rooms/${currentRoom}/turn`] = opponentId;

        update(ref(db), updates);
    }, { onlyOnce: true });
}

// Utility to create a card DOM element
function createCardElement(value) {
    const card = document.createElement('div');
    card.className = 'game-card';
    card.innerText = value;
    return card;
}
