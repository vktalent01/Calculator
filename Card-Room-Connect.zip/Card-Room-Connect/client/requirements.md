## Packages
firebase | Realtime database for game state synchronization
framer-motion | Smooth animations for card drawing, playing, and hovering
lucide-react | Icons for UI elements
uuid | Generating unique player IDs for the game session

## Notes
- Expects Firebase Realtime Database. 
- If Firebase environment variables (VITE_FIREBASE_API_KEY, etc.) are not provided, the app uses a LocalStorage-based fallback for cross-tab local testing.
- Uses the provided standard REST API for room creation/validation, and Firebase (or fallback) for high-frequency game state synchronization.
