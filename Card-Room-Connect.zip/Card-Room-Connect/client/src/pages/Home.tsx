import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { v4 as uuidv4 } from "uuid";
import { motion } from "framer-motion";
import { useCreateRoom } from "@/hooks/use-rooms";
import { generateRoomCode } from "@/lib/utils";
import { Spade, Diamond, Loader2 } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [error, setError] = useState("");
  const createRoom = useCreateRoom();

  // Initialize or get player ID
  useEffect(() => {
    if (!localStorage.getItem("verdant_player_id")) {
      localStorage.setItem("verdant_player_id", uuidv4());
    }
    const savedName = localStorage.getItem("verdant_player_name");
    if (savedName) setName(savedName);
  }, []);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value);
    localStorage.setItem("verdant_player_name", e.target.value);
    setError("");
  };

  const handleCreate = async () => {
    if (!name.trim()) {
      setError("Please enter your name first.");
      return;
    }
    
    try {
      const code = generateRoomCode();
      await createRoom.mutateAsync(code);
      setLocation(`/room/${code}`);
    } catch (err: any) {
      setError(err.message || "Failed to create room");
    }
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Please enter your name first.");
      return;
    }
    if (!joinCode.trim() || joinCode.length !== 6) {
      setError("Please enter a valid 6-character room code.");
      return;
    }
    setLocation(`/room/${joinCode.toUpperCase()}`);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10">
          <div className="flex justify-center items-center gap-3 mb-4">
             <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center text-primary-foreground shadow-lg rotate-12">
                <Spade size={24} className="fill-current" />
             </div>
             <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-destructive shadow-lg -rotate-12 border border-border">
                <Diamond size={24} className="fill-current" />
             </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold text-foreground tracking-tight">VERDANT</h1>
          <p className="text-muted-foreground mt-2 font-medium">A minimalist multiplayer card experience.</p>
        </div>

        <div className="bg-card p-6 md:p-8 rounded-3xl shadow-xl border border-white/50 backdrop-blur-sm">
          <div className="space-y-6">
            
            {/* Name Input */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-foreground ml-1">YOUR NAME</label>
              <input
                type="text"
                value={name}
                onChange={handleNameChange}
                placeholder="Enter your alias..."
                className="w-full px-5 py-4 rounded-2xl bg-background border-2 border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all text-lg font-medium"
                maxLength={15}
              />
            </div>

            {error && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-destructive text-sm font-semibold px-2">
                {error}
              </motion.div>
            )}

            <div className="pt-4 space-y-4">
              <button
                onClick={handleCreate}
                disabled={createRoom.isPending}
                className="w-full px-6 py-4 rounded-2xl font-bold text-lg bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 flex justify-center items-center"
              >
                {createRoom.isPending ? <Loader2 className="animate-spin" /> : "Host New Game"}
              </button>

              <div className="relative flex items-center py-2">
                <div className="flex-grow border-t border-border"></div>
                <span className="flex-shrink-0 mx-4 text-muted-foreground text-sm font-bold uppercase tracking-wider">OR JOIN</span>
                <div className="flex-grow border-t border-border"></div>
              </div>

              <form onSubmit={handleJoin} className="flex gap-2">
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => {
                    setJoinCode(e.target.value.toUpperCase());
                    setError("");
                  }}
                  placeholder="6-DIGIT CODE"
                  className="flex-grow px-5 py-4 rounded-2xl bg-background border-2 border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all text-center font-display font-bold tracking-widest text-lg"
                  maxLength={6}
                />
                <button
                  type="submit"
                  className="px-8 py-4 rounded-2xl font-bold bg-white border-2 border-border text-foreground shadow-sm hover:border-primary/50 hover:bg-primary/5 transition-all duration-200"
                >
                  Join
                </button>
              </form>
            </div>

          </div>
        </div>
      </motion.div>
    </div>
  );
}
