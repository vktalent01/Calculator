import React, { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useRoom } from "@/hooks/use-rooms";
import { useFirebaseGame } from "@/hooks/use-firebase-game";
import { PlayingCard } from "@/components/PlayingCard";
import { PlayerAvatar } from "@/components/PlayerAvatar";
import { motion, AnimatePresence } from "framer-motion";
import { Copy, LogOut, Play, RefreshCw, AlertTriangle, Layers } from "lucide-react";
import { Card as CardType } from "@/lib/game-logic";

export default function Room() {
  const [match, params] = useRoute("/room/:code");
  const [, setLocation] = useLocation();
  const code = params?.code || "";
  
  // API check to see if room exists
  const { data: roomData, isLoading: roomLoading, error: roomError } = useRoom(code);
  
  const playerId = localStorage.getItem("verdant_player_id") || "unknown";
  const playerName = localStorage.getItem("verdant_player_name") || "Guest";

  const { gameState, loading: gameLoading, error: gameError, isMock, actions } = useFirebaseGame(code, playerId);

  const [copied, setCopied] = useState(false);

  // Auto-join logic
  useEffect(() => {
    if (gameState && !gameState.players?.[playerId] && gameState.status === 'waiting') {
      actions.joinGame(playerName);
    }
  }, [gameState, playerId, playerName, actions]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLeave = () => {
    setLocation("/");
  };

  if (roomLoading || gameLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4 text-primary">
        <RefreshCw className="animate-spin w-10 h-10" />
        <p className="font-display font-bold animate-pulse">Connecting to Table...</p>
      </div>
    );
  }

  if (roomError || gameError || !roomData) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <div className="bg-white p-8 rounded-3xl shadow-xl max-w-md w-full text-center border-2 border-destructive/20">
          <AlertTriangle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Room Unavailable</h2>
          <p className="text-muted-foreground mb-8">
            {gameError || "This room code doesn't exist or the session has expired."}
          </p>
          <button onClick={handleLeave} className="w-full px-6 py-4 bg-primary text-white rounded-2xl font-bold hover:opacity-90 transition-opacity">
            Return Home
          </button>
        </div>
      </div>
    );
  }

  if (!gameState) return null;

  const players = Object.values(gameState.players || {});
  const myPlayer = gameState.players?.[playerId];
  const isHost = gameState.hostId === playerId;
  const isMyTurn = gameState.currentTurnId === playerId;
  
  // Opponents for UI layout (excluding self)
  const opponents = players.filter(p => p.id !== playerId);

  return (
    <div className="min-h-screen flex flex-col overflow-hidden bg-background">
      {/* Top Bar */}
      <header className="px-4 md:px-8 py-4 flex items-center justify-between z-10 relative">
        <div className="flex items-center gap-4">
          <button onClick={handleLeave} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm text-muted-foreground hover:text-foreground transition-colors border border-border">
            <LogOut size={18} className="ml-[-2px]" />
          </button>
          
          <div className="bg-white px-4 py-2 rounded-full shadow-sm border border-border flex items-center gap-3">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">ROOM</span>
            <span className="font-display font-bold text-lg tracking-widest text-primary">{code}</span>
            <button 
              onClick={handleCopyCode}
              className="text-muted-foreground hover:text-primary transition-colors ml-1"
              title="Copy Room Code"
            >
              <Copy size={16} />
            </button>
            {copied && <span className="absolute top-16 left-24 bg-foreground text-background text-xs px-2 py-1 rounded shadow-md pointer-events-none animate-in fade-in slide-in-from-bottom-2">Copied!</span>}
          </div>
        </div>

        {isMock && (
          <div className="hidden md:flex items-center gap-2 bg-amber-100 text-amber-800 px-4 py-2 rounded-full text-xs font-bold shadow-sm">
            <AlertTriangle size={14} />
            Local Sync Mode (No Firebase)
          </div>
        )}

        <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm border border-border text-sm font-semibold">
           <Layers size={16} className="text-primary" />
           {gameState.deck?.length || 0} cards left
        </div>
      </header>

      {/* Main Game Area */}
      <main className="flex-1 relative flex flex-col justify-between pt-4 pb-8 px-4 md:px-8">
        
        {/* Opponents Area (Top) */}
        <div className="flex justify-center gap-8 md:gap-16 min-h-[100px]">
          <AnimatePresence>
            {opponents.map(opp => (
              <motion.div key={opp.id} initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
                <PlayerAvatar 
                  name={opp.name} 
                  cardCount={opp.hand?.length || 0} 
                  isTurn={gameState.currentTurnId === opp.id}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Center Table Area */}
        <div className="flex-1 flex flex-col items-center justify-center relative my-8">
           <div className="absolute inset-0 max-w-4xl mx-auto rounded-[3rem] game-table-pattern opacity-50 border-4 border-primary/10 shadow-[inset_0_10px_30px_rgba(0,0,0,0.05)] -z-10" />
           
           {/* Event Message */}
           <motion.div 
             key={gameState.message}
             initial={{ opacity: 0, y: -10 }}
             animate={{ opacity: 1, y: 0 }}
             className="absolute top-4 bg-white/80 backdrop-blur-md px-6 py-2 rounded-full shadow-sm border border-white font-medium text-sm text-foreground z-20 text-center max-w-[80%]"
           >
             {gameState.message}
           </motion.div>

           {gameState.status === 'waiting' ? (
             <div className="text-center z-10">
               {isHost ? (
                 <button 
                   onClick={actions.startGame}
                   disabled={players.length < 2}
                   className="px-8 py-4 bg-primary text-primary-foreground rounded-2xl font-bold shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all disabled:opacity-50 disabled:hover:translate-y-0 flex items-center gap-2 text-lg"
                 >
                   <Play className="fill-current" />
                   Start Game
                 </button>
               ) : (
                 <p className="font-display text-2xl font-bold text-muted-foreground bg-white/50 px-8 py-6 rounded-3xl backdrop-blur-sm">
                   Waiting for host to start...
                 </p>
               )}
               {players.length < 2 && isHost && (
                 <p className="mt-4 text-sm font-semibold text-muted-foreground/80">Share the code to invite players</p>
               )}
             </div>
           ) : (
             <div className="flex items-center gap-8 md:gap-16 z-10 scale-90 sm:scale-100">
                {/* Deck */}
                <div className="relative">
                  <div className="absolute -inset-4 rounded-2xl border-2 border-dashed border-primary/20 pointer-events-none" />
                  {gameState.deck && gameState.deck.length > 0 ? (
                    <PlayingCard 
                      faceDown 
                      onClick={actions.drawCard}
                      className={isMyTurn ? "hover:-translate-y-2 hover:shadow-lg transition-transform ring-4 ring-primary/20 ring-offset-4 ring-offset-background" : "opacity-80"}
                    />
                  ) : (
                    <div className="playing-card rounded-xl border-2 border-dashed border-primary/20 flex items-center justify-center bg-white/30 backdrop-blur-sm">
                      <span className="text-primary/40 font-bold text-sm text-center">DECK<br/>EMPTY</span>
                    </div>
                  )}
                  {isMyTurn && (
                    <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-primary text-white text-xs font-bold px-3 py-1 rounded-full shadow-md pointer-events-none animate-bounce">
                      Draw
                    </div>
                  )}
                </div>

                {/* Table / Play Pile */}
                <div className="relative w-[100px] sm:w-[120px] md:w-[140px] h-[140px] sm:h-[168px] md:h-[196px]">
                  <div className="absolute inset-0 rounded-xl border-2 border-dashed border-primary/20 bg-primary/5 flex items-center justify-center -z-10">
                     <span className="text-primary/30 font-bold tracking-widest">TABLE</span>
                  </div>
                  <AnimatePresence>
                    {gameState.table && gameState.table.map((card, idx) => {
                      // Only show last few cards to prevent DOM bloat, stack them
                      if (idx < gameState.table.length - 3) return null;
                      const isLast = idx === gameState.table.length - 1;
                      // Generate slight random rotation based on card id so it looks messy
                      const rot = parseInt(card.id.substring(0,2), 16) % 30 - 15;
                      return (
                         <motion.div
                           key={card.id}
                           initial={{ opacity: 0, scale: 1.5, y: 100 }}
                           animate={{ opacity: 1, scale: 1, y: 0, rotate: rot }}
                           className={cn("absolute inset-0", !isLast && "opacity-70 pointer-events-none")}
                           style={{ zIndex: idx }}
                         >
                           <PlayingCard card={card} />
                         </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
             </div>
           )}
        </div>

        {/* My Hand Area (Bottom) */}
        <div className="relative pt-10 mt-auto">
          {/* My Player Info */}
          <div className="absolute top-0 left-4 md:left-8 -translate-y-1/2 z-20">
             <PlayerAvatar 
               name={playerName} 
               isMe 
               isTurn={isMyTurn}
               cardCount={myPlayer?.hand?.length || 0}
               className="flex-row items-center gap-4"
             />
          </div>

          <div className="bg-card border-t border-l border-r border-white/80 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] rounded-t-[2.5rem] p-4 md:p-8 min-h-[220px] relative flex justify-center backdrop-blur-xl">
             
             {myPlayer?.hand && myPlayer.hand.length > 0 ? (
               <div className="flex justify-center flex-wrap gap-[-40px] sm:gap-[-20px] max-w-full">
                 <AnimatePresence>
                   {myPlayer.hand.map((card, idx) => (
                     <motion.div
                       key={card.id}
                       layout
                       className="relative -ml-8 sm:-ml-4 first:ml-0"
                       style={{ zIndex: idx }}
                     >
                       <PlayingCard 
                         card={card} 
                         isPlayable={isMyTurn}
                         onClick={() => actions.playCard(card.id)}
                         index={idx}
                         className={isMyTurn ? "ring-2 ring-primary/0 hover:ring-primary/50 ring-offset-2 ring-offset-card" : ""}
                       />
                     </motion.div>
                   ))}
                 </AnimatePresence>
               </div>
             ) : (
               <div className="flex items-center justify-center h-full w-full opacity-50">
                 <p className="font-display font-bold text-xl text-muted-foreground border-2 border-dashed border-border rounded-2xl px-12 py-8">
                   {gameState.status === 'playing' ? "Your hand is empty." : "Waiting to be dealt..."}
                 </p>
               </div>
             )}

             {/* Host Controls */}
             {isHost && gameState.status === 'playing' && (
               <button 
                 onClick={actions.resetGame}
                 className="absolute bottom-4 right-4 md:right-8 bg-white border border-border shadow-sm px-4 py-2 rounded-xl text-xs font-bold text-muted-foreground hover:text-destructive hover:border-destructive/30 transition-colors flex items-center gap-2"
               >
                 <RefreshCw size={14} /> Reset
               </button>
             )}
          </div>
        </div>

      </main>
    </div>
  );
}
