import React from 'react';
import { User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface PlayerAvatarProps {
  name: string;
  isTurn?: boolean;
  cardCount?: number;
  isMe?: boolean;
  className?: string;
}

export function PlayerAvatar({ name, isTurn, cardCount, isMe, className }: PlayerAvatarProps) {
  const initials = name.substring(0, 2).toUpperCase();

  return (
    <div className={cn("flex flex-col items-center gap-2", className)}>
      <motion.div 
        animate={isTurn ? { 
          boxShadow: ['0 0 0 0 rgba(var(--primary), 0)', '0 0 0 4px hsla(var(--primary) / 0.3)', '0 0 0 0 rgba(var(--primary), 0)'],
        } : {}}
        transition={isTurn ? { duration: 2, repeat: Infinity } : {}}
        className={cn(
          "w-14 h-14 rounded-full flex items-center justify-center font-display font-bold text-lg relative",
          isMe ? "bg-primary text-primary-foreground" : "bg-white text-foreground border-2 border-border shadow-sm"
        )}
      >
        {initials}
        
        {cardCount !== undefined && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-accent text-accent-foreground text-xs flex items-center justify-center font-bold shadow-md border-2 border-background">
            {cardCount}
          </div>
        )}
      </motion.div>
      <div className={cn(
        "text-xs sm:text-sm font-semibold px-3 py-1 rounded-full",
        isTurn ? "bg-primary/10 text-primary" : "text-muted-foreground",
        isMe && "bg-primary/5 border border-primary/20"
      )}>
        {name} {isMe && "(You)"}
      </div>
    </div>
  );
}
