import React from 'react';
import { motion } from 'framer-motion';
import { Card as CardType } from '@/lib/game-logic';
import { cn } from '@/lib/utils';
import { Heart, Diamond, Club, Spade } from 'lucide-react';

interface PlayingCardProps {
  card?: CardType;
  faceDown?: boolean;
  onClick?: () => void;
  className?: string;
  isPlayable?: boolean;
  index?: number;
}

export function PlayingCard({ card, faceDown = false, onClick, className, isPlayable = false, index = 0 }: PlayingCardProps) {
  const isRed = card?.suit === 'hearts' || card?.suit === 'diamonds';
  
  const getSuitIcon = () => {
    if (!card) return null;
    switch (card.suit) {
      case 'hearts': return <Heart className="fill-current" size={16} />;
      case 'diamonds': return <Diamond className="fill-current" size={16} />;
      case 'clubs': return <Club className="fill-current" size={16} />;
      case 'spades': return <Spade className="fill-current" size={16} />;
    }
  };

  const getSuitIconLarge = () => {
    if (!card) return null;
    switch (card.suit) {
      case 'hearts': return <Heart className="fill-current opacity-20" size={64} />;
      case 'diamonds': return <Diamond className="fill-current opacity-20" size={64} />;
      case 'clubs': return <Club className="fill-current opacity-20" size={64} />;
      case 'spades': return <Spade className="fill-current opacity-20" size={64} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.8 }}
      whileHover={isPlayable && !faceDown ? { y: -15, zIndex: 50, scale: 1.05 } : {}}
      transition={{ duration: 0.2, delay: index * 0.05 }}
      onClick={isPlayable || onClick ? onClick : undefined}
      className={cn(
        "playing-card relative rounded-xl flex items-center justify-center cursor-pointer select-none",
        "shadow bg-white border-2",
        isPlayable ? "hover:shadow-xl hover:border-primary/30" : "",
        !isPlayable && !onClick ? "cursor-default" : "",
        className
      )}
      style={{
        transformOrigin: "bottom center"
      }}
    >
      {faceDown ? (
        // Card Back
        <div className="absolute inset-1 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center overflow-hidden">
           <div className="w-full h-full game-table-pattern opacity-30"></div>
           <div className="absolute w-8 h-8 rounded-full border-2 border-primary/40 flex items-center justify-center">
             <div className="w-4 h-4 rounded-full bg-primary/40"></div>
           </div>
        </div>
      ) : (
        // Card Front
        <div className={cn("w-full h-full p-2 sm:p-3 flex flex-col justify-between font-display relative overflow-hidden", isRed ? "text-destructive" : "text-slate-800")}>
          <div className="flex flex-col items-center self-start leading-none">
            <span className="text-lg sm:text-xl font-bold">{card?.rank}</span>
            <span className="mt-1">{getSuitIcon()}</span>
          </div>
          
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             {getSuitIconLarge()}
          </div>

          <div className="flex flex-col items-center self-end leading-none rotate-180">
            <span className="text-lg sm:text-xl font-bold">{card?.rank}</span>
            <span className="mt-1">{getSuitIcon()}</span>
          </div>
        </div>
      )}
    </motion.div>
  );
}
