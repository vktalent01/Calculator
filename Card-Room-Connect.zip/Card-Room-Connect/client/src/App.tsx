import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "./pages/Home";
import Room from "./pages/Room";
import { useEffect, useState } from "react";
import { ref, onValue, update, get } from "firebase/database";
import { db } from "./firebase"; // adjust path if needed

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/room/:code" component={Room} />
      <Route component={NotFound} />
    </Switch>
  );
}

function generateMinimizeDeck() {
  const colors = ["red", "yellow", "green", "blue"];
  const deck: any[] = [];

  // Number cards 1–12 (2 copies each)
  colors.forEach(color => {
    for (let num = 1; num <= 12; num++) {
      deck.push({ type: "number", color, value: num });
      deck.push({ type: "number", color, value: num });
    }
  });

  return deck.sort(() => Math.random() - 0.5);
}

function App() {
  const [roomCode, setRoomCode] = useState("");
  const [roomData, setRoomData] =  useState<any>(null);
  const [myName, setMyName] = useState("");
  const [myKey, setMyKey] = useState("");
  useEffect(() => {
  if (!roomCode) return;

  const roomRef = ref(db, "rooms/" + roomCode);

  onValue(roomRef, async (snapshot) => {
    const data = snapshot.val();
    if (!data) return;

    setRoomData(data);

    const players = data.players ? Object.keys(data.players) : [];

    // Find my key
    for (let key in data.players) {
      if (data.players[key] === myName) {
        setMyKey(key);
      }
    }

    // Start game when 2 players join
    if (players.length === 2 && !data.gameStarted) {
      const deck = generateMinimizeDeck();

      const hands: any = {};
      hands[players[0]] = deck.splice(0, 7);
      hands[players[1]] = deck.splice(0, 7);

      await update(roomRef, {
        gameStarted: true,
        deck: deck,
        hands: hands,
        currentTurn: players[0]
      });
    }
  });
}, [roomCode, myName]);
  const playCard = async (cardIndex: number) => {
  const roomRef = ref(db, "rooms/" + roomCode);
  const snapshot = await get(roomRef);
  const data = snapshot.val();

  if (data.currentTurn !== myKey) {
    alert("Not your turn!");
    return;
  }

  const myHand = [...data.hands[myKey]];
  myHand.splice(cardIndex, 1);

  const updatedHands = {
    ...data.hands,
    [myKey]: myHand
  };

  const otherPlayer = Object.keys(data.hands).find(
    k => k !== myKey
  );

  await update(roomRef, {
    hands: updatedHands,
    currentTurn: otherPlayer
  });
};
  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Router />

      {/* Game UI */}
      {roomData?.gameStarted && roomData?.hands?.[myKey] && (
        <div style={{ padding: "20px" }}>
          <h3>Your Cards</h3>

          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            {roomData.hands[myKey].map((card: any, index: number) => (
              <button
                key={index}
                onClick={() => playCard(index)}
                style={{
                  padding: "10px",
                  background: card.color,
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer"
                }}
              >
                {card.value}
              </button>
            ))}
          </div>
        </div>
      )}

    </TooltipProvider>
  </QueryClientProvider>
  );
}

export default App;
