import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

// Utility to parse responses and log Zod errors
function parseResponse<T>(schema: any, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod Error] ${label}:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

export function useRoom(code: string) {
  return useQuery({
    queryKey: [api.rooms.get.path, code],
    queryFn: async () => {
      if (!code) return null;
      const url = buildUrl(api.rooms.get.path, { code });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch room");
      const data = await res.json();
      return parseResponse<any>(api.rooms.get.responses[200], data, "room.get");
    },
    enabled: !!code,
  });
}

export function useCreateRoom() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (code: string) => {
      const payload = { code };
      const res = await fetch(api.rooms.create.path, {
        method: api.rooms.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 400) {
          throw new Error(data.message || "Validation failed");
        }
        throw new Error("Failed to create room");
      }
      return parseResponse<any>(api.rooms.create.responses[201], data, "room.create");
    },
    onSuccess: (_, code) => {
      queryClient.invalidateQueries({ queryKey: [api.rooms.get.path, code] });
    },
  });
}
