import { useState, useEffect, useCallback, useRef } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { getDatabase, ref, onValue, set, update, get } from 'firebase/database';
import { GameState, INITIAL_GAME_STATE, Card, createDeck } from '@/lib/game-logic';

// --- CONFIGURATION ---
// IMPORTANT: Replace these with your actual Firebase config
// If these remain "PLACEHOLDER", the app will use an in-memory/localStorage mock
// so that the template is still usable for demonstration purposes.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "PLACEHOLDER",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "PLACEHOLDER",
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || "https://placeholder-default-rtdb.firebaseio.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "PLACEHOLDER",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "PLACEHOLDER",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "PLACEHOLDER",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "PLACEHOLDER"
};

const isMock = firebaseConfig.apiKey === "PLACEHOLDER";

// Initialize Firebase only if not mocking
let db: any = null;
if (!isMock) {
  try {
    const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
    db = getDatabase(app);
  } catch (e) {
    console.error("Firebase init error, falling back to mock", e);
  }
}

// Custom hook to manage Firebase (or mocked) game state
export function useFirebaseGame(roomCode: string, playerId: string) {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Synchronization effect
  useEffect(() => {
    if (!roomCode) return;

    if (!isMock && db) {
      // REAL FIREBASE SYNC
      const gameRef = ref(db, `rooms/${roomCode}`);
      
      const unsubscribe = onValue(gameRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          setGameState(data);
        } else {
          // Initialize empty game state in Firebase
          set(gameRef, INITIAL_GAME_STATE);
        }
        setLoading(false);
      }, (err) => {
        setError(err.message);
        setLoading(false);
      });

      return () => unsubscribe();
    } else {
      // LOCALSTORAGE MOCK SYNC (For template demonstration without credentials)
      console.log("Using LocalStorage mock for Firebase RTDB");
      const storageKey = `verdant_game_${roomCode}`;
      
      const loadLocalState = () => {
        const stored = localStorage.getItem(storageKey);
        if (stored) {
          setGameState(JSON.parse(stored));
        } else {
          localStorage.setItem(storageKey, JSON.stringify(INITIAL_GAME_STATE));
          setGameState(INITIAL_GAME_STATE);
        }
        setLoading(false);
      };

      loadLocalState();

      // Listen for other tabs updating the same storage key
      const handleStorage = (e: StorageEvent) => {
        if (e.key === storageKey && e.newValue) {
          setGameState(JSON.parse(e.newValue));
        }
      };

      // Also poll frequently for same-tab updates not caught by storage event
      const interval = setInterval(loadLocalState, 500);
      
      window.addEventListener('storage', handleStorage);
      return () => {
        window.removeEventListener('storage', handleStorage);
        clearInterval(interval);
      };
    }
  }, [roomCode]);

  // Actions
  const updateGame = useCallback(async (updates: Partial<GameState>) => {
    if (!gameState) return;
    
    const newState = { ...gameState, ...updates };
    
    // Optimistic update
    setGameState(newState as GameState);

    if (!isMock && db) {
      const gameRef = ref(db, `rooms/${roomCode}`);
      await update(gameRef, updates);
    } else {
      localStorage.setItem(`verdant_game_${roomCode}`, JSON.stringify(newState));
    }
  }, [gameState, roomCode]);

  const joinGame = useCallback(async (playerName: string) => {
    if (!gameState) return;
    
    const isHost = Object.keys(gameState.players || {}).length === 0;
    
    const newPlayers = {
      ...(gameState.players || {}),
      [playerId]: {
        id: playerId,
        name: playerName,
        hand: [],
        score: 0
      }
    };

    await updateGame({
      players: newPlayers,
      hostId: isHost ? playerId : gameState.hostId,
      message: `${playerName} joined the table.`
    });
  }, [gameState, playerId, updateGame]);

  const startGame = useCallback(async () => {
    if (!gameState || gameState.hostId !== playerId) return;

    const deck = createDeck();
    const players = { ...gameState.players };
    
    // Deal 5 cards to each player
    Object.keys(players).forEach(pId => {
      players[pId].hand = deck.splice(0, 5);
    });

    const firstPlayerId = Object.keys(players)[0];

    await updateGame({
      status: 'playing',
      deck,
      players,
      table: [],
      currentTurnId: firstPlayerId,
      message: 'Game started!'
    });
  }, [gameState, playerId, updateGame]);

  const drawCard = useCallback(async () => {
    if (!gameState || gameState.currentTurnId !== playerId || gameState.deck.length === 0) return;

    const deck = [...gameState.deck];
    const drawn = deck.pop();
    if (!drawn) return;

    const players = { ...gameState.players };
    players[playerId].hand = [...(players[playerId].hand || []), drawn];

    // Find next player turn
    const playerIds = Object.keys(players);
    const currentIndex = playerIds.indexOf(playerId);
    const nextPlayerId = playerIds[(currentIndex + 1) % playerIds.length];

    await updateGame({
      deck,
      players,
      currentTurnId: nextPlayerId,
      message: `${players[playerId].name} drew a card.`
    });
  }, [gameState, playerId, updateGame]);

  const playCard = useCallback(async (cardId: string) => {
    if (!gameState || gameState.currentTurnId !== playerId) return;

    const players = { ...gameState.players };
    const myHand = [...(players[playerId].hand || [])];
    
    const cardIndex = myHand.findIndex(c => c.id === cardId);
    if (cardIndex === -1) return;

    const [playedCard] = myHand.splice(cardIndex, 1);
    players[playerId].hand = myHand;

    const table = [...(gameState.table || []), playedCard];

    // Next turn
    const playerIds = Object.keys(players);
    const currentIndex = playerIds.indexOf(playerId);
    const nextPlayerId = playerIds[(currentIndex + 1) % playerIds.length];

    await updateGame({
      players,
      table,
      currentTurnId: nextPlayerId,
      message: `${players[playerId].name} played ${playedCard.rank} of ${playedCard.suit}.`
    });
  }, [gameState, playerId, updateGame]);

  const resetGame = useCallback(async () => {
    if (!gameState || gameState.hostId !== playerId) return;
    
    const players = { ...gameState.players };
    Object.keys(players).forEach(pId => {
      players[pId].hand = [];
      players[pId].score = 0;
    });

    await updateGame({
      status: 'waiting',
      players,
      deck: [],
      table: [],
      message: 'Game reset. Waiting to start...'
    });
  }, [gameState, playerId, updateGame]);

  return {
    gameState,
    loading,
    error,
    isMock,
    actions: {
      joinGame,
      startGame,
      drawCard,
      playCard,
      resetGame
    }
  };
}
