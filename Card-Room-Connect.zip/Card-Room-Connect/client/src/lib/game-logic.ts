export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type Rank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  id: string;
  suit: Suit;
  rank: Rank;
}

export interface Player {
  id: string;
  name: string;
  hand: Card[];
  score: number;
}

export interface GameState {
  status: 'waiting' | 'playing' | 'finished';
  players: Record<string, Player>;
  deck: Card[];
  table: Card[];
  currentTurnId: string | null;
  hostId: string | null;
  message: string;
}

export const createDeck = (): Card[] => {
  const suits: Suit[] = ['yellow', 'red', 'blue', 'green'];
  const ranks: Rank[] = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
  const deck: Card[] = [];

  for (const suit of suits) {
    for (const rank of ranks) {
      deck.push({ id: `${rank}-${suit}-${Math.random().toString(36).substr(2, 9)}`, suit, rank });
    }
  }

  // Shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return deck;
};

export const INITIAL_GAME_STATE: GameState = {
  status: 'waiting',
  players: {},
  deck: [],
  table: [],
  currentTurnId: null,
  hostId: null,
  message: 'Waiting for players...',
};
