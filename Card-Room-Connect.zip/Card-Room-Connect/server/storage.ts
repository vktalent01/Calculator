import { db } from "./db";
import { rooms, type Room } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getRoom(code: string): Promise<Room | undefined>;
  createRoom(code: string): Promise<Room>;
  updateRoomState(code: string, gameState: any): Promise<Room>;
}

export class DatabaseStorage implements IStorage {
  async getRoom(code: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.code, code));
    return room;
  }

  async createRoom(code: string): Promise<Room> {
    const [room] = await db.insert(rooms).values({ code, gameState: {} }).returning();
    return room;
  }

  async updateRoomState(code: string, gameState: any): Promise<Room> {
    const [room] = await db.update(rooms)
      .set({ gameState })
      .where(eq(rooms.code, code))
      .returning();
    return room;
  }
}

export const storage = new DatabaseStorage();
